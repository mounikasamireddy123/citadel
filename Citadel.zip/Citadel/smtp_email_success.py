#!/usr/bin/python
import sys
import smtplib
import os
import time
import re
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from rq import Queue
from redis import Redis

def mail_success():
  
  port = 2525
  smtp_server = "smtp.mailtrap.io"
  login= "Abc@12345"
  password = "India@2016"
  From= 'xyz@gmail.com'
  To = 'abc@gmail.com'

  message1 = MIMEMultipart()
  message1['Subject'] = "Thank you for your interest. You are eligible for the role"
  message1['From'] = "Recruiting Team <xyz@gmail.com>"
  message1['To'] = To
  rcpt = bcc.split(",")  + [To]
  msgAlternative = MIMEMultipart('alternative')

  html = """\
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html> 
    <head>
<!-- If you delete this meta tag, the ground will open and swallow you. -->
<meta name="viewport" content="width=device-width" />
<meta https-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Mail</title>
<style>
* ------------------------------------- 
                GLOBAL 
------------------------------------- */
* {
        margin:0;
        padding:0;
}
* { font-family: "Helvetica Neue", "Helvetica", Helvetica, Arial, sans-serif; }

img {
        max-width: 100%;
}
.collapse {
        margin:0;
        padding:0;
}
body {
        -webkit-font-smoothing:antialiased;
        -webkit-text-size-adjust:none;
        width: 100%!important;
        height: 100%;
}

/* ------------------------------------- 
                HEADER 
------------------------------------- */
table.head-wrap { width: 100%;}

.header.container table td.logo { padding: 15px; }
.header.container table td.label { padding: 15px; padding-left:0px;}

/* ------------------------------------- 
                BODY 
------------------------------------- */
table.body-wrap { width: 100%;}


/* ------------------------------------- 
                FOOTER 
------------------------------------- */
table.footer-wrap { width: 100%;        clear:both!important;
}
.footer-wrap .container td.content  p { border-top: 1px solid rgb(215,215,215); padding-top:15px;}
.footer-wrap .container td.content p {
        font-size:10px;
        font-weight: bold;

}


</style>

    </head>
<body bgcolor="#FFFFFF" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0">
<!-- HEADER -->
<table class="head-wrap" >
        <tr>
                <td></td>
                <td class="header container" align="">

                        <!-- /content -->
                       

                </td>
                <td></td>
        </tr>
</table><!-- /HEADER -->

<table class="body-wrap" bgcolor="">
        <tr>
                <td class="container" align="" bgcolor="#FFFFFF">

                        <!-- content -->
                        <div class="content">
                                <table>
                                        <tr>
                                                <td>
                                                    <p><b>Hi</b>, <br/><br/>
                                                    Thank you for your interest. You are eligible for the role<br/>
                                                    We look forward to working with you.</p>
                                                </td>
                                        </tr>
                                </table>
                        </div><!-- /content -->
                        <div class="content">
                        <p>Warmest regards,</p>                                                                                            <h4 class="">Recruiting Team</h4>  
                        <p>Phone: <strong>123456789</strong><br/>
                Email: <strong><a href="emailto:xyz@gmail.com">xyz@gmail.com</a></strong></p>



                        </div><!-- /content -->
                </td>
        </tr>               
</table>

<html>
 """
 
 part = MIMEText(html, "html")
 message.attach(part)
 #send your email
 with smtplib.SMTP("smtp.mailtrap.io", 2525) as server:
    server.login(login,password)
    server.sendmail(
        server_email, receiver_email, message.as_string() )

 