#!/usr/bin/python
import imaplib
import email
import os

def download_attachment():
    
    svdir = 'c:/downloads'

#email_id and password to access emails.
    email_user = input('Email: ')
    email_pass = input('Password: ')
    mail = imaplib.IMAP4_SSL(“imap.gmail.com”,993)
    mail.login(email_user, email_pass)
    mail.select('Inbox')

    typ, data = mail.search(None, 'ALL')
    msgs = msgs[0].split()

    for emailid in msgs:
        resp, data = mail.fetch(emailid, "(RFC822)") # Internet Message Access Protocol
        email_body = data[0][1]
        m = email.message_from_string(email_body)

# multipart if emails contain attachments
        if m.get_content_maintype() != 'multipart':
            continue

# Generate the filename in the directory tree
        for part in m.walk():
            if part.get_content_maintype() == 'multipart':
                continue
            if part.get('Content-Disposition') is None:
                continue

            filename = part.get_filename()
            if filename is not None:
                sv_path = os.path.join(svdir, filename)
                if not os.path.isfile(sv_path):
                    print(sv_path)
                    fp = open(sv_path, 'wb')
                    fp.write(part.get_payload(decode=True))
                    fp.close()
                subject = str(email_message).split("Subject: ", 1)[1].split("\nTo:", 1)[0]
                print('Downloaded "{file}" from email titled "{subject}" with UID {uid}.'.format(file=fileName, subject=subject, uid=latest_email_uid.decode('utf-8')))
    return filename
                
                
                