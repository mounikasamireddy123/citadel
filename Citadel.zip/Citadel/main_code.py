#!/usr/bin/python
import sys
import os
import PyPDF2
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.MIMEImage import MIMEImage
from mail_success import *
from mail_failed import *
import re

def find_keyword():

    list_file = open('list.txt')
    search_words = []
    for word in list_file:
        search_words.append(word.strip())
    list_file.close()

    object = PyPDF2.PdfFileReader("test.pdf")
    NumPages = object.getNumPages()

    match_textCount=0

    for j in search_words:
        for i in range(0, NumPages):
            PageObj = object.getPage(i)
            print("this is page" + str(i))
            Text = PageObj.extractText()
            ResSearch = re.search(search_words[j], Text)
        
            if ResSearch:
                match_textCount++

    if match_textCount != 0:
        mail_success()
    else:
        mail_failed()
        
            
        

